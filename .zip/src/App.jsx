import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <header>
      Sistema y Gestión de inventario para farmacias
      <h1>
        Farmalink
      </h1>
    </header>


      <div id ="Menu">
        <aside className="Menu">
          <h2>Menú de navegación</h2>
          <nav>
            <ul>
              <li><a href="#">Productos</a></li>
              <li><a href="#">Compras</a></li>
              <li><a href="#">Empleados</a></li>
              <li><a href="#">Alertas</a></li>
            </ul>
          </nav>
        </aside>
      </div>



  <div>
    
  </div>




    {/*
      <div>
        <a href="https://tailwindcss-es.com/" target="_blank">
          <img src={"data:image/webp;base64,UklGRq4RAABXRUJQVlA4IKIRAADQjACdASqhAasAPp1Mm0qlpLgkpdUNgwATiWVsYSEkSQzfb/s568OHiXBzM619OQig+hBTj/GCI3l5gL//6LH79/iP7X/lf2x97v17/w/XQ02g3f1XbXcu9J+YXSqc4SJXs4yH6i9gD9EP1M/m3Z980v7eevB6Xf+j6UfU3b0Fgnf+O73fcb8fqDFP/0R/S0STjgpIHMXSoo5GYr/7MssEt3Ciop0vNwfU2YOSXkKSk2Uk8X9GQMtVceJH85RuxB+6ptu0VW8e+f/5gByoTLFr9ppWazQUWB9OE+wTnrov/M0xsr5OPGKQ9XreqcjvDCTipQtYYKI/+MpqJ4WpIhhV5SszhErSxFvEXlbRGaIBKmPtaQTH/1QK/o6AeY/0NCoIige11SmT6iko7X08Mi3FsPHxfmwtQExQIiUXz2z5EH9VEDGRQ6ZtlUrwzx6qjwpsYihk4VvJ9ExxDEdeb9oNf1dq2Km1T9w+IfGoieIZS6mxvGdV9HiP3shXVvaWrJRjzAV8gNy5tVqLiPKzxdDwGM71CWtLmdAKsrmx35k0k4Jge3Adv/qZJmQ/ngAIdS3qF0WOhVtxc3Dx8APQeOB1V4X7INaJQA4sPqUNz2zhtmho18MO15DKdNNbVqCf+6KGNgnr5mB2kO6f2ejt4xJ74TTEC+Pm2yPQX2RLSzL9L5YBZdzEOltmSsgpAFELq4dOPf8Mws2dfvHGuqQ1BnMVc5bTmfGG/HRzgt/BLNI+YIM86ciFyCCJR85tGugcAW4HKDZqpQDxtPV+Fh1cxr8XRJ08DRfLSKJsYnaN+i0+/DlGQ8k5cx4oSIdYVK/U1nlZDlT3ZmDA5eaAOn615HIrJIasL/d4wn2X+eZ+S2I0RkYbBe/E23mNwoClz73Il+qh/RwtoCRJ20s6Xto3fU9hTaYlbyM/wO0os+uzmYS57sYhuwgkHttajQZIvWceFMS23jVU9OrKIpJhwRxJM2nL9QkomM3QXUXfDZMNpYbxNNuAcrvdm7ska66sOv77e6qVa7GGs09xLPXCTAPHby+/AkeKu199VnzRwHFEM5tXz2kq0o3h7FS5/BFAZ+ERJJLm22KwNRec9my9tATOd4PpTB4n65ByzkQwhMTKGbzYdd68sidK9AR5qTSPVBpP1WMPpzaimR1me5h4dMDUY5gYI8FOtA08Yl7GXpDEsINK3srYBPKOcGipfyPulRMkplbnQ8FDa09nCwu0LaROPpHaq+3ZTJwZ5s8u9Qa8SuIAdFpZqPG4o4lei+gj7MN0AORlt4UE+vMV3HlLaX1jj44hVa4m9Xtz/IueehrBRDBFaPSX1jFnrCNDpWdEM3gH7eATbOxPvFSbcCkWIw0vd5Vns9pwQFA7T99kejuVXEvhIIFYzAD0REGNSJUSSsZ0Jxt6adZCIFPmxuRtonGZab1AyAXo5BxvGCuLerVYTp2sNeC0NLTdN5FAsPkMp6dj5/40cW0iaxIat1kHJSoliyOqjRNWq44rAWHcd48/Pw+AAP7mARzbjelrNGlWPOa8TwyF83xhBzVgqs8bPVCOl1pEYF9YvpxEReWr23wJcXofWsfS63mQ4AHVb1R6NvmPeAeNN+0K15h/hHJeaWnJOzi1UUqBJ2hObwjSE6ORU2k4sChtLeDVTKMkSKA7XegBdY5fnSsHMMcQHOCldPPz9g/5UTIknbQiVpPBYopCyJG2G9bpkolZNTNdKldmS6VJEWY4ahj5Nu7Syg6JPsH3Qi/V27kyT6B9O1qlT7K+kiHzkmko/hzU/KO+Iv+yzVht2WPLgp+S1CZ+8HPr4PGR/Kv5bqj9mcJ6eqAIxSEaKKtnEOIwZ5WeQ+/wi3tzPxb/oLWGbnLiKhngajjriaFMW6APJJTO15SoD7fVOyi3OZ/zIUbs1Oqlcyozk6ChZrrJ+2FhemryzNocl92g255+PJcagyomOspLZan76ixIplW/KPosefBBGmy4Uh9Amevcj5nGaOJJxtsctRpc5WAZYPYjDcFS4RL/X9YtcuSA5TtlzV8v3/tRD6w/B3Pzgq6Dkl4UCxZAxADecK4Mr1InV1UnN9kn0k7CMH6i7KWAd0zItB84xp05sy6giGH5bbJs6Jtj3jc9tE02gB5qdhN785LcEjjZq2HriK+xPFj3M+RD9ueT3PnH9qp6ujZrk79PwpzpqxtmjEVdbQ80Nt3wp1Zgtdf+AdjF/EZaciKqa88G8aypE7O7EInpJy0fiMkF54iAN800z6qDv/vyxHX5DcTWAi96/3nnYeHAxzQs5DALVGceGZ/sZlxrIL9j17UbhBW0h3Xfgi2x3CYt3rV2XCrDu56ext3dznxxWmS74dEVltgPGBlXOlynzRXAmH58mbeks1xMERvRRZ5e1aS8yyp1PrtTOBrfYYmfjvFAAQ7rdoozIcmXXN0aUhWrS37zuSYH6m+0laiR7MzcNGiE7a0xqM6ayQEcH8tf8fvux0kJsXt1Rg9pBaTPsmz7hMk+zChEvOzBnWpM4wz0IBJyecbb7wjXsO/kvURv6Fz2ftAZprLQHL5SGGeUQHzBwORjgy0F4txA9akVwhTYSZ5rEO0S7Badekb2iVr0hdmeQem9EiCvJnSKVBAa1nO4wgzoPsUTIHFH7J0M+EWaIZ+d03xDGwyNgcBgEYy0yl283b0BwFZ/zeNMNGpYghedCV+hWzRH9d/u0G58OZaYxVOBbhdy2POWjX8dRY05rRInZA1uJaeRtlQSK/HiuEEB9cdH56a5eYkLC374qJtiUyaKho5XHqZ7EdG9ToTW8Y7TeophK8kwunETUQ3H9uwMAE5wd2z2ZmSD8LLzEnw2CNmuvKKb4N4293ntORFI0Jvk/djwNcSq57gzKeTNUh6IEGEt7Djl5w6gUJZJD0MFpiMYFz+T6KkDWN90xt7MMPdNGEAvM/20NLcvnCQLi5uCMoQ6Fuw+Upx/69MphAyL3bDITPq40UkvVkHeas/IJkKOZbvX6veu02L2yvwjylqJL1H7qI/9bOPIR3utuCXQOBz1QVD3DMplbiMybVqA5rr7lLNW3SfCqjGbzj8PZjepRVPpTl09lBBNUnXQptWzb/8Y0cCTdmigrWt8tVSmIcQ/WmRAJdsg7GwUp+V4Rrj6gDbPZHhUpWTGixcn7nbI+JtLaltiMwBGOToLTU68ju0wkUjdrf8RT5ZDTGwz16K2cHL7FnFrpJ394JU7f02dTmTg4ffaCZA8KHZN6TZ3NGSJHbCCCoabtkAX2JUu7qAjXLVeZpkVwTe5XJWI1SKAHIs7DJPPlv8xp0veSYK2Y0t8K83gwrAFxmCvQpfac35Ti0ChERl7yw8qowpSmLjL+gGhKSM4+1honOk+7+kR1BBfsNNp67aDXChsmbHyoVpizoHLyQpqY736c1VAFCVEkZAA1Z8eG1FYfWXs0T7QqrOescm2re7R+lh/HTLy0WkPy0aoKZ2s3vOQaTqDool1d/CzDrjcP9M4mg3tS1Ld0Aam7iEV+fKYOlqy6aWr3PgYwPuC1Z9Qs4WPBMYNQvoXhmjQRb0B7Rdk2HPOGHtc/+8yuT3/GejmK2wxMuqUdDNV6zmFqI1VXMUhW8GxrJk+17wGZaMCaaq1uAuvqLKM7kpVkTsdI9ICAK0uAT+mVmm3IiXMLnk3PdVeyEdnCnlBmqtxfEulp3eanLldYoM1NuMKU8eB+wfLwWSAiiW7Kq+Ub57b91SBQ8fOGQlaRcbW83ww6dBzafyg8IFAZHikPixppXlvmCJvHqtlp+E6nq0XQlL/Gy3lV9e+sPs5Nyl0cBwxgHpXh3poAsLpMtQHOvC0GE9K+2yavoVAn4SefFaYbjWYAFU9Ri7EQjfOXxI38KUFu8NMQCQFDpfqht35irYgLaOoolsmFN8/OZT2wJ/aEzNeXA+6v9eFObsYqIC0ebvx9hJ8yyLgENt2ioo3G0/FQmUxqKcP66k3BJtfYPHT7Klq73PI8G/FjpZzC42j58Ynyr3S/ySC1kKm0/yVzSsjSRGOJ6nfy6H5RJoboZ5KWB6ncUGD0kUZFbIry8O/qaIsLT8202mIOlLr7s0MolVmmqAqAK78IhqK6Z2JXN8eX9NWlPOt1lCQtcOZ57xERvFcVkLhygYP/oiI3ixMynZySrUBIQHCVEq7ttpG0ugo5d5pEM6eb6mL6uDlKoI9H01st2eUh0i6PuJvq/j3dOFTkLPKlqQvWbT9XlZ31ArSvE4xFIyljnAzK60+WI+RZHLS/v/YiXJIDbkboEa2URgzIK1G4vAOLPaNthMj8ier3sP1pkrGGHVHGc2UKWahk8l1QYJCIp3hpsFukbtPeL5xdKpE8osneK6NpIDK3wl0xAWTjXUosto5rUeBhWc+/+bVG0zL7tz5jsuoZg5gLna3lZI+Qroyn1pcIuYmeloY+o2uhUvelr2xwMf7S4IA+Po8i8D6Qe09zHOonezuLYnMVAbP+ZTW8lGdDCihq+5XpmvahCmvoDxA/MwXm7kqlGG/ME85fdhTETKroRnJjUt1m8UeMfUqOsvFRab9Xu5YCnFQUAFWbV+4v6IxHsSaFxw2WbMBBwfYpXX4Y1AZK9CePb+fcHMbXYLjd1719xMkO8ck8wMB79wp5lRqEdHPWdYI6OI8R5tnvFPus31AZIP08eDIgCn8HpXPF7p97vEdXPYRh7Z9DfHQHo1Hy2e8HGnyxK9XtmXTAAogMxNXuK8gkcspdn96fxU4/PXKr9VRR4KQlfVksZDKIB1rilBO/dw/MZsiP0/8escfZ//IKeHb1mZC6tjNotp21EvSbgprP7hj26GBGdztH4K196r2a6kLoT0PsP3WUQI0Mm0JFYSbpr07x18EIuYmeloY+w6hwDOe5xQNDpk1vnT+TnFxI4+pnJvfvgD/djKA0q9ra7+hI1qCXNcCxgnzGn0g5WLh8HVRZGNEKI8sm9NyNnKreqX4nItkOBzSAQwEChZfXzuMg4Mo/zfG66CxxxfDqmDXVy+srdhYuafhKgwMtuQQDzKj4KHwTc/wff5Jxr+PgElbePax+036+YUQc73cgBLwq5hIn2OvzyFoTZWqBqokdaP3juUT/inUucu+4qrRVilpknqGyh5Jme26ru8MtIE28hXGEhGC2u1y/j0LbISE1vai80O05HwVp03fBWn4EAx3A0oicxQBM8UeSuM2xzF5+9QuYsoK1uHoOyIN09REFkYqstqU/TFVQ7WeACsiJv+eidSlyiXkr2iaDoqwLoxETsB6zg17HOhAVn0lX8w+r2tk+Pou8iKlzYnN9CRLHnAk8kKq6ikgUGfm8r9/RFbIi7nnyWExnEDP9SlQj0NB+fCLpeBiBlGMe592asPn4QjHoFvZnDhkfgJM9X41+P2ja5Qx5wn/PHyJ0yQfEfKw0CcIsxKowNMz3lozSpTm7E54zmk2T4tQnWGZH3qNKU5ZX+NPeprfDK6ViaauPeLvnFOsQcQ91ZO5N0lyy2/LvFOYw2vWeTIieiX3E3SOJyY0WYHuf95V0YNPD0g2jbNxzsbLEiUS6QNBoT1W54wErPo7FLf1cp5jWWnEuy/CYgKNTfkyAHUYSunhFnQPM1rsdKs6Sl/zwppQXRceO3UMasnsUIo+Ppvx2bsTeZivSBx8xncjYA9FE6t9lbzTVN8YpVjUQ92GmHnqsE6q3jyei4riYSOXboLXyx8zetQrARJOT62bnVX26YkjGOevU3mpZ+t3z+U75jELgD+bNI/tDW7TXR1BUnhHeLP68VI8fY/TCCCYAsSRB0i+luc7iDUzCbUQsYZUmO+HAa1xL2woBs4ZSLEGfYNCS1mQ6nNbe95jCZKpd3bc3wnqrnTFDO7I1EkLKxa1bmjLJkHrGLLipt1ss/yHtJmPFg9yA/JxsUoKBCNVwSCj/9ewR/8lRsCF3zCwdraCULw4FCK+Z5XSMcfa0AUxMiTGH9h/JwJAVrA1tmpIwWS9JqiA57KpaWl4cFQS8HuWcTGwcGd8AbmuVtcUAcFSKqYX5deTagdSJ6PsXEHZsAAAAA=="} className="logo" alt="" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
    */}


      {/*<div className="card">
        <button onClick={() => setCount((count) => count + 1)}>
          count is {count}
        </button>
        <p>
          Edit <code>src/App.jsx</code> and save to test HMR
        </p>
      </div>
      <p className="read-the-docs">
        <h3>Contacto</h3>
        Click on the Vite and React logos to learn more
      </p>*/}
    </>
  )
}



export default App
